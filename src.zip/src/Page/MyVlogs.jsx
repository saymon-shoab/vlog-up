import React from 'react'

const MyVlogs = () => {
  return (
    <div>MyVlogs</div>
  )
}

export default MyVlogs