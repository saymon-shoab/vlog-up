import React from 'react'

const Id = () => {
  return (
    <div>Id</div>
  )
}

export default Id