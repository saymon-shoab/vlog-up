import React from 'react'

const EditVlog = () => {
  return (
    <div>EditVlog</div>
  )
}

export default EditVlog